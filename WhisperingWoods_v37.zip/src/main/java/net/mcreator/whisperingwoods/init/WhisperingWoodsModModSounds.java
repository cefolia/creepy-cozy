/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.whisperingwoods.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

import net.mcreator.whisperingwoods.WhisperingWoodsModMod;

public class WhisperingWoodsModModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(Registries.SOUND_EVENT, WhisperingWoodsModMod.MODID);
	public static final DeferredHolder<SoundEvent, SoundEvent> ENTITY_GNOME_STEP = REGISTRY.register("entity.gnome.step", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("whispering_woods_mod", "entity.gnome.step")));
	public static final DeferredHolder<SoundEvent, SoundEvent> MUSIC_WHISPERING_WOODS = REGISTRY.register("music.whispering_woods",
			() -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("whispering_woods_mod", "music.whispering_woods")));
	public static final DeferredHolder<SoundEvent, SoundEvent> ENTITY_GNOME_DEATH = REGISTRY.register("entity.gnome.death",
			() -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("whispering_woods_mod", "entity.gnome.death")));
	public static final DeferredHolder<SoundEvent, SoundEvent> AMBIENT_WHISPERING_WOODS_MOOD = REGISTRY.register("ambient.whispering_woods.mood",
			() -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("whispering_woods_mod", "ambient.whispering_woods.mood")));
	public static final DeferredHolder<SoundEvent, SoundEvent> ENTITY_GHOST_STEP = REGISTRY.register("entity.ghost.step", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("whispering_woods_mod", "entity.ghost.step")));
	public static final DeferredHolder<SoundEvent, SoundEvent> ENTITY_GHOST_DEATH = REGISTRY.register("entity.ghost.death",
			() -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("whispering_woods_mod", "entity.ghost.death")));
	public static final DeferredHolder<SoundEvent, SoundEvent> ENTITY_DEER_DEATH = REGISTRY.register("entity.deer.death", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("whispering_woods_mod", "entity.deer.death")));
	public static final DeferredHolder<SoundEvent, SoundEvent> ENTITY_DEER_AMBIENT = REGISTRY.register("entity.deer.ambient",
			() -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("whispering_woods_mod", "entity.deer.ambient")));
	public static final DeferredHolder<SoundEvent, SoundEvent> AMBIENT_WHISPERING_WOODS_CAVE = REGISTRY.register("ambient.whispering_woods.cave",
			() -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("whispering_woods_mod", "ambient.whispering_woods.cave")));
	public static final DeferredHolder<SoundEvent, SoundEvent> ENTITY_GNOME_AMBIENT = REGISTRY.register("entity.gnome.ambient",
			() -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("whispering_woods_mod", "entity.gnome.ambient")));
	public static final DeferredHolder<SoundEvent, SoundEvent> ENTITY_GNOME_HURT = REGISTRY.register("entity.gnome.hurt", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("whispering_woods_mod", "entity.gnome.hurt")));
}