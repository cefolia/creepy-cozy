// Made with Blockbench 4.12.6
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports

public class ModelDeerFinal<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
			new ResourceLocation("modid", "deerfinal"), "main");
	private final ModelPart Body;
	private final ModelPart LegBL;
	private final ModelPart LegBR;
	private final ModelPart LegFl;
	private final ModelPart LegFR;
	private final ModelPart Tail;
	private final ModelPart Neck;
	private final ModelPart Head;
	private final ModelPart Jaw;
	private final ModelPart JawU;
	private final ModelPart JawT;
	private final ModelPart EarL;
	private final ModelPart EarR;
	private final ModelPart NeckB;

	public ModelDeerFinal(ModelPart root) {
		this.Body = root.getChild("Body");
		this.LegBL = this.Body.getChild("LegBL");
		this.LegBR = this.Body.getChild("LegBR");
		this.LegFl = this.Body.getChild("LegFl");
		this.LegFR = this.Body.getChild("LegFR");
		this.Tail = this.Body.getChild("Tail");
		this.Neck = this.Body.getChild("Neck");
		this.Head = this.Neck.getChild("Head");
		this.Jaw = this.Head.getChild("Jaw");
		this.JawU = this.Jaw.getChild("JawU");
		this.JawT = this.Jaw.getChild("JawT");
		this.EarL = this.Head.getChild("EarL");
		this.EarR = this.Head.getChild("EarR");
		this.NeckB = this.Neck.getChild("NeckB");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition Body = partdefinition.addOrReplaceChild("Body",
				CubeListBuilder.create().texOffs(0, 0).addBox(-10.0F, -5.0F, -4.0F, 20.0F, 9.0F, 8.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 10.0F, 0.0F, 0.0F, -1.5708F, 0.0F));

		PartDefinition LegBL = Body.addOrReplaceChild("LegBL", CubeListBuilder.create().texOffs(22, 27).addBox(-1.5F,
				0.0F, -1.5F, 3.0F, 10.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offset(8.5F, 4.0F, -2.5F));

		PartDefinition LegBR = Body.addOrReplaceChild("LegBR", CubeListBuilder.create().texOffs(34, 27).addBox(-1.5F,
				0.0F, -1.5F, 3.0F, 10.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offset(8.5F, 4.0F, 2.5F));

		PartDefinition LegFl = Body.addOrReplaceChild("LegFl", CubeListBuilder.create().texOffs(12, 40).addBox(-1.5F,
				0.0F, -1.5F, 3.0F, 10.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offset(-6.5F, 4.0F, -2.5F));

		PartDefinition LegFR = Body.addOrReplaceChild("LegFR", CubeListBuilder.create().texOffs(0, 36).addBox(-1.5F,
				0.0F, -1.5F, 3.0F, 10.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offset(-6.5F, 4.0F, 2.5F));

		PartDefinition Tail = Body.addOrReplaceChild("Tail",
				CubeListBuilder.create().texOffs(38, 40)
						.addBox(-0.1128F, -0.4F, -2.0F, 1.0F, 3.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(46, 30)
						.addBox(-0.2F, 1.5924F, -1.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(10.0F, -5.0F, 0.0F, 0.0F, 0.0F, -0.0873F));

		PartDefinition Neck = Body.addOrReplaceChild("Neck", CubeListBuilder.create(),
				PartPose.offsetAndRotation(4.0F, 11.0F, 0.0F, 0.0F, 0.0F, -0.3491F));

		PartDefinition Head = Neck.addOrReplaceChild("Head", CubeListBuilder.create(),
				PartPose.offset(-8.0F, -15.0F, 0.0F));

		PartDefinition AntlerR_r1 = Head.addOrReplaceChild("AntlerR_r1",
				CubeListBuilder.create().texOffs(46, 35)
						.addBox(-8.9622F, -32.2989F, 1.0F, 1.0F, 3.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(32, 46)
						.addBox(-8.9622F, -32.2989F, -2.0F, 1.0F, 3.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(4.0F, 18.0F, 0.0F, 0.0F, 0.0F, 0.1745F));

		PartDefinition Head_r1 = Head.addOrReplaceChild("Head_r1",
				CubeListBuilder.create().texOffs(0, 17).addBox(0.9468F, -1.1794F, -1.5F, 6.0F, 14.0F, 5.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-5.0F, -11.0F, -1.0F, 0.0F, 0.0F, -0.1745F));

		PartDefinition Jaw = Head.addOrReplaceChild("Jaw", CubeListBuilder.create(),
				PartPose.offset(4.0F, 18.0F, 0.0F));

		PartDefinition JawU = Jaw.addOrReplaceChild("JawU", CubeListBuilder.create(),
				PartPose.offset(0.0F, 0.0F, 0.0F));

		PartDefinition JawU_r1 = JawU.addOrReplaceChild("JawU_r1",
				CubeListBuilder.create().texOffs(24, 40).addBox(7.239F, -8.5171F, -2.0F, 3.0F, 2.0F, 4.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-19.0F, -24.0F, 0.0F, 0.0F, 0.0F, 0.2182F));

		PartDefinition JawT = Jaw.addOrReplaceChild("JawT", CubeListBuilder.create(),
				PartPose.offset(0.0F, 0.0F, 0.0F));

		PartDefinition JawT_r1 = JawT.addOrReplaceChild("JawT_r1",
				CubeListBuilder.create().texOffs(12, 36).addBox(8.239F, -6.5171F, -1.5F, 2.0F, 1.0F, 3.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-19.0F, -24.0F, 0.0F, 0.0F, 0.0F, 0.2182F));

		PartDefinition EarL = Head.addOrReplaceChild("EarL", CubeListBuilder.create(),
				PartPose.offset(0.0F, -12.0F, -2.0F));

		PartDefinition EarL_r1 = EarL.addOrReplaceChild("EarL_r1",
				CubeListBuilder.create().texOffs(46, 27).addBox(1.4948F, -1.0F, -1.027F, 3.0F, 2.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 1.0F, 2.0F, -0.5337F, 1.1377F, -0.4436F));

		PartDefinition EarR = Head.addOrReplaceChild("EarR", CubeListBuilder.create(),
				PartPose.offset(0.0F, -12.0F, 2.0F));

		PartDefinition EarR_r1 = EarR.addOrReplaceChild("EarR_r1",
				CubeListBuilder.create().texOffs(24, 46).addBox(-4.4948F, -1.0F, -1.027F, 3.0F, 2.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 1.0F, -2.0F, 2.6079F, 1.1377F, 2.698F));

		PartDefinition NeckB = Neck.addOrReplaceChild("NeckB", CubeListBuilder.create(),
				PartPose.offset(-5.0F, -19.0F, 0.0F));

		PartDefinition NeckT_r1 = NeckB
				.addOrReplaceChild("NeckT_r1",
						CubeListBuilder.create().texOffs(22, 17).addBox(1.5927F, -2.2133F, -2.0F, 10.0F, 6.0F, 4.0F,
								new CubeDeformation(0.0F)),
						PartPose.offsetAndRotation(-4.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.829F));

		return LayerDefinition.create(meshdefinition, 64, 64);
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay,
			float red, float green, float blue, float alpha) {
		Body.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}

	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
			float headPitch) {
	}
}