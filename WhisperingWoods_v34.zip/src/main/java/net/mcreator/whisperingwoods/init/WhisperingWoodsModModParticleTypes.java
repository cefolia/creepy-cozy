/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.whisperingwoods.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.core.registries.Registries;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleType;

import net.mcreator.whisperingwoods.WhisperingWoodsModMod;

public class WhisperingWoodsModModParticleTypes {
	public static final DeferredRegister<ParticleType<?>> REGISTRY = DeferredRegister.create(Registries.PARTICLE_TYPE, WhisperingWoodsModMod.MODID);
	public static final DeferredHolder<ParticleType<?>, SimpleParticleType> VIOLET_FIREFLIES = REGISTRY.register("violet_fireflies", () -> new SimpleParticleType(false));
}