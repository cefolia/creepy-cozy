package net.mcreator.whisperingwoods.client.model;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.EntityModel;

// Made with Blockbench 5.0.3
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports
public class Modelgnome_model extends EntityModel<LivingEntityRenderState> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath("whispering_woods_mod", "modelgnome_model"), "main");
	public final ModelPart body;
	public final ModelPart face;
	public final ModelPart hat;
	public final ModelPart beard;
	public final ModelPart right_arm;
	public final ModelPart left_arm;
	public final ModelPart right_leg;
	public final ModelPart left_leg;
	public final ModelPart neck;

	public Modelgnome_model(ModelPart root) {
		super(root);
		this.body = root.getChild("body");
		this.face = this.body.getChild("face");
		this.hat = this.body.getChild("hat");
		this.beard = this.body.getChild("beard");
		this.right_arm = this.body.getChild("right_arm");
		this.left_arm = this.body.getChild("left_arm");
		this.right_leg = this.body.getChild("right_leg");
		this.left_leg = this.body.getChild("left_leg");
		this.neck = this.body.getChild("neck");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();
		PartDefinition body = partdefinition.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 9).addBox(-4.8916F, 2.8906F, -1.6026F, 6.0F, 2.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(0, 0)
				.addBox(-4.8916F, -2.6094F, -1.6026F, 6.0F, 5.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(20, 5).addBox(-4.3916F, 1.8906F, -1.1026F, 5.0F, 1.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offset(1.8916F, 17.1094F, -0.3974F));
		PartDefinition face = body.addOrReplaceChild("face",
				CubeListBuilder.create().texOffs(18, 15).addBox(-2.0F, -1.38F, -1.275F, 4.0F, 3.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(16, 31).addBox(-3.0F, -0.38F, 0.475F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(20, 31)
						.addBox(2.0F, -0.38F, 0.475F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(30, 24).addBox(-1.0F, -0.53F, -1.7F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(24, 31)
						.addBox(-0.5F, -0.83F, -1.975F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offset(-1.8916F, -4.7294F, -0.3276F));
		PartDefinition hat = body.addOrReplaceChild("hat",
				CubeListBuilder.create().texOffs(20, 13).addBox(-2.5F, -0.2801F, -1.9464F, 5.0F, 1.0F, 1.0F, new CubeDeformation(0.01F)).texOffs(20, 0).addBox(-2.0F, -1.1301F, -1.4964F, 4.0F, 1.0F, 4.0F, new CubeDeformation(0.01F)).texOffs(30, 30)
						.addBox(1.5F, 0.7199F, -0.9964F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 31).addBox(-2.5F, 0.7199F, -0.9964F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 15)
						.addBox(-2.5F, -0.7801F, -1.4964F, 5.0F, 2.0F, 4.0F, new CubeDeformation(0.02F)),
				PartPose.offset(-1.8916F, -6.0793F, 0.1438F));
		PartDefinition hat_tip_r1 = hat.addOrReplaceChild("hat_tip_r1", CubeListBuilder.create().texOffs(8, 25).addBox(-1.0F, -0.5F, -1.0F, 2.0F, 1.0F, 2.0F, new CubeDeformation(0.01F)),
				PartPose.offsetAndRotation(0.0F, -1.9598F, 0.8499F, -0.1745F, 0.0F, 0.0F));
		PartDefinition hat_main_3_r1 = hat.addOrReplaceChild("hat_main_3_r1", CubeListBuilder.create().texOffs(20, 9).addBox(-1.5F, -0.5F, -1.5F, 3.0F, 1.0F, 3.0F, new CubeDeformation(0.01F)),
				PartPose.offsetAndRotation(0.0F, -1.2896F, 0.5823F, -0.0873F, 0.0F, 0.0F));
		PartDefinition beard = body.addOrReplaceChild("beard",
				CubeListBuilder.create().texOffs(0, 21).addBox(-2.208F, -2.2935F, -0.6071F, 4.3F, 1.75F, 1.0F, new CubeDeformation(0.01F)).texOffs(18, 22).addBox(-1.858F, -1.0435F, -0.5571F, 3.8F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 24)
						.addBox(-1.608F, -0.2935F, -0.4571F, 3.3F, 2.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(28, 22).addBox(-1.108F, 1.7065F, -0.4821F, 2.3F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(4, 31)
						.addBox(-0.458F, 2.4565F, -0.3821F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offset(-1.9836F, -2.3159F, -1.4955F));
		PartDefinition l_mustache_r1 = beard.addOrReplaceChild("l_mustache_r1", CubeListBuilder.create().texOffs(30, 26).addBox(-1.0F, -0.5F, -0.5F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-1.6914F, -1.9748F, -0.0071F, 0.0F, 0.0F, 0.1745F));
		PartDefinition r_mustache_r1 = beard.addOrReplaceChild("r_mustache_r1", CubeListBuilder.create().texOffs(30, 28).addBox(-1.0F, -0.5F, -0.5F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(1.5816F, -1.9326F, -0.0071F, 0.0F, 0.0F, -0.1745F));
		PartDefinition right_arm = body.addOrReplaceChild("right_arm", CubeListBuilder.create(), PartPose.offset(1.7588F, 0.2118F, 0.1474F));
		PartDefinition right_arm_r1 = right_arm.addOrReplaceChild("right_arm_r1", CubeListBuilder.create().texOffs(24, 24).addBox(-0.5F, -2.5F, -0.75F, 1.0F, 5.0F, 1.5F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.0873F));
		PartDefinition left_arm = body.addOrReplaceChild("left_arm", CubeListBuilder.create(), PartPose.offset(-5.6197F, 0.2016F, 0.1474F));
		PartDefinition left_arm_r1 = left_arm.addOrReplaceChild("left_arm_r1", CubeListBuilder.create().texOffs(18, 24).addBox(-0.5F, -2.5F, -0.75F, 1.0F, 5.0F, 1.5F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0873F));
		PartDefinition right_leg = body.addOrReplaceChild("right_leg", CubeListBuilder.create().texOffs(0, 27).addBox(-0.75F, -1.0F, -0.75F, 1.5F, 2.0F, 1.5F, new CubeDeformation(0.0F)), PartPose.offset(-0.3916F, 5.8906F, 0.3974F));
		PartDefinition left_leg = body.addOrReplaceChild("left_leg", CubeListBuilder.create().texOffs(8, 28).addBox(-0.75F, -1.0F, -0.75F, 1.5F, 2.0F, 1.5F, new CubeDeformation(0.0F)), PartPose.offset(-3.3916F, 5.8906F, 0.3974F));
		PartDefinition neck = body.addOrReplaceChild("neck", CubeListBuilder.create().texOffs(10, 21).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offset(-1.8916F, -3.1094F, 0.3974F));
		return LayerDefinition.create(meshdefinition, 64, 64);
	}

	public void setupAnim(LivingEntityRenderState state) {
		float limbSwing = state.walkAnimationPos;
		float limbSwingAmount = state.walkAnimationSpeed;
		float ageInTicks = state.ageInTicks;
		float netHeadYaw = state.yRot;
		float headPitch = state.xRot;

	}

}