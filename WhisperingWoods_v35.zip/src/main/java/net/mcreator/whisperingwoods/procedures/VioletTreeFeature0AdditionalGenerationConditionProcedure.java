package net.mcreator.whisperingwoods.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

public class VioletTreeFeature0AdditionalGenerationConditionProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		boolean success = false;
		success = true;
		if (!world.isEmptyBlock(BlockPos.containing(x, y + 1, z)) || !world.isEmptyBlock(BlockPos.containing(x, y + 2, z))) {
			success = false;
		}
	}
}