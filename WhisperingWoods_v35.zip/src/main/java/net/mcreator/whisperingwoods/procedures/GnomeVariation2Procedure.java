package net.mcreator.whisperingwoods.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.whisperingwoods.entity.GnomeEntity;

public class GnomeVariation2Procedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		return (entity instanceof GnomeEntity _datEntI ? _datEntI.getEntityData().get(GnomeEntity.DATA_textureID) : 0) == 2;
	}
}