/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.whisperingwoods.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.whisperingwoods.client.model.ModelowlEntity;
import net.mcreator.whisperingwoods.client.model.Modelhornedowl;
import net.mcreator.whisperingwoods.client.model.Modelgnome_varient_1_Converted_Converted;
import net.mcreator.whisperingwoods.client.model.Modelgnome_model;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class WhisperingWoodsModModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(Modelhornedowl.LAYER_LOCATION, Modelhornedowl::createBodyLayer);
		event.registerLayerDefinition(Modelgnome_varient_1_Converted_Converted.LAYER_LOCATION, Modelgnome_varient_1_Converted_Converted::createBodyLayer);
		event.registerLayerDefinition(ModelowlEntity.LAYER_LOCATION, ModelowlEntity::createBodyLayer);
		event.registerLayerDefinition(Modelgnome_model.LAYER_LOCATION, Modelgnome_model::createBodyLayer);
	}
}