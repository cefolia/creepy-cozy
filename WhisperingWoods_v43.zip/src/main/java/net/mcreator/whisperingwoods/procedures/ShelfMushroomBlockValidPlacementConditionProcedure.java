package net.mcreator.whisperingwoods.procedures;

import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import net.mcreator.whisperingwoods.init.WhisperingWoodsModModBlocks;

public class ShelfMushroomBlockValidPlacementConditionProcedure {
	public static boolean execute(LevelAccessor world, double x, double y, double z, BlockState blockstate) {
		if ((getDirectionFromBlockState(blockstate)) == Direction.NORTH && world.getBlockState(BlockPos.containing(x, y, z + 1)).isFaceSturdy(world, BlockPos.containing(x, y, z + 1), Direction.NORTH)
				&& ((world.getBlockState(BlockPos.containing(x, y, z + 1))).getBlock() == WhisperingWoodsModModBlocks.WHISPERING_LOG.get()
						|| (world.getBlockState(BlockPos.containing(x, y, z + 1))).getBlock() == WhisperingWoodsModModBlocks.STRIPPED_WHISPERING_LOG.get())) {
			return true;
		} else if ((getDirectionFromBlockState(blockstate)) == Direction.SOUTH && world.getBlockState(BlockPos.containing(x, y, z - 1)).isFaceSturdy(world, BlockPos.containing(x, y, z - 1), Direction.SOUTH)
				&& ((world.getBlockState(BlockPos.containing(x, y, z - 1))).getBlock() == WhisperingWoodsModModBlocks.WHISPERING_LOG.get()
						|| (world.getBlockState(BlockPos.containing(x, y, z - 1))).getBlock() == WhisperingWoodsModModBlocks.STRIPPED_WHISPERING_LOG.get())) {
			return true;
		} else if ((getDirectionFromBlockState(blockstate)) == Direction.EAST && world.getBlockState(BlockPos.containing(x - 1, y, z)).isFaceSturdy(world, BlockPos.containing(x - 1, y, z), Direction.EAST)
				&& ((world.getBlockState(BlockPos.containing(x - 1, y, z))).getBlock() == WhisperingWoodsModModBlocks.WHISPERING_LOG.get()
						|| (world.getBlockState(BlockPos.containing(x - 1, y, z))).getBlock() == WhisperingWoodsModModBlocks.STRIPPED_WHISPERING_LOG.get())) {
			return true;
		} else if ((getDirectionFromBlockState(blockstate)) == Direction.WEST && world.getBlockState(BlockPos.containing(x + 1, y, z)).isFaceSturdy(world, BlockPos.containing(x + 1, y, z), Direction.WEST)
				&& ((world.getBlockState(BlockPos.containing(x + 1, y, z))).getBlock() == WhisperingWoodsModModBlocks.WHISPERING_LOG.get()
						|| (world.getBlockState(BlockPos.containing(x + 1, y, z))).getBlock() == WhisperingWoodsModModBlocks.STRIPPED_WHISPERING_LOG.get())) {
			return true;
		}
		return false;
	}

	private static Direction getDirectionFromBlockState(BlockState blockState) {
		if (blockState.getBlock().getStateDefinition().getProperty("facing") instanceof EnumProperty ep && ep.getValueClass() == Direction.class)
			return (Direction) blockState.getValue(ep);
		if (blockState.getBlock().getStateDefinition().getProperty("axis") instanceof EnumProperty ep && ep.getValueClass() == Direction.Axis.class)
			return Direction.fromAxisAndDirection((Direction.Axis) blockState.getValue(ep), Direction.AxisDirection.POSITIVE);
		return Direction.NORTH;
	}
}