/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.creepycozy.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.creepycozy.item.GnomePickaxeItem;
import net.mcreator.creepycozy.item.GnomeArmorItem;
import net.mcreator.creepycozy.item.GhostWorldItem;
import net.mcreator.creepycozy.CreepyCozyMod;

import java.util.function.Function;

public class CreepyCozyModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(CreepyCozyMod.MODID);
	public static final DeferredItem<Item> GHOST_SPAWN_EGG = register("ghost_spawn_egg", properties -> new SpawnEggItem(CreepyCozyModEntities.GHOST.get(), properties));
	public static final DeferredItem<Item> HAUNTED_TULIP = block(CreepyCozyModBlocks.HAUNTED_TULIP, new Item.Properties().fireResistant());
	public static final DeferredItem<Item> GHOST_WORLD = register("ghost_world", GhostWorldItem::new);
	public static final DeferredItem<Item> OWL_SPAWN_EGG = register("owl_spawn_egg", properties -> new SpawnEggItem(CreepyCozyModEntities.OWL.get(), properties));
	public static final DeferredItem<Item> GNOME_SPAWN_EGG = register("gnome_spawn_egg", properties -> new SpawnEggItem(CreepyCozyModEntities.GNOME.get(), properties));
	public static final DeferredItem<Item> GNOME_ARMOR_HELMET = register("gnome_armor_helmet", GnomeArmorItem.Helmet::new);
	public static final DeferredItem<Item> GNOME_ARMOR_BOOTS = register("gnome_armor_boots", GnomeArmorItem.Boots::new);
	public static final DeferredItem<Item> GNOME_PICKAXE = register("gnome_pickaxe", GnomePickaxeItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}