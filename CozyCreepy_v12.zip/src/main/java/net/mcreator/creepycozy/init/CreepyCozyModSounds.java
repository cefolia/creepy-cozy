/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.creepycozy.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

import net.mcreator.creepycozy.CreepyCozyMod;

public class CreepyCozyModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(Registries.SOUND_EVENT, CreepyCozyMod.MODID);
	public static final DeferredHolder<SoundEvent, SoundEvent> MOD_BIOMEBACKTRACK = REGISTRY.register("mod.biomebacktrack", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("creepy_cozy", "mod.biomebacktrack")));
}