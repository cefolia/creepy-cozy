package net.mcreator.whisperingwoods.procedures;

import net.minecraft.world.level.LevelAccessor;

public class VioletTreeSaplingOnBoneMealSuccessProcedure {
	public static void execute(LevelAccessor world) {
		if (!world.isClientSide()) {
		}
	}
}