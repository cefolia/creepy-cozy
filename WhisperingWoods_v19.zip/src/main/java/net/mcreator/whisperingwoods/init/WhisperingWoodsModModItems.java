/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.whisperingwoods.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.whisperingwoods.item.GnomePickaxeItem;
import net.mcreator.whisperingwoods.item.GnomeArmorItem;
import net.mcreator.whisperingwoods.item.GhostWorldItem;
import net.mcreator.whisperingwoods.WhisperingWoodsModMod;

import java.util.function.Function;

public class WhisperingWoodsModModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(WhisperingWoodsModMod.MODID);
	public static final DeferredItem<Item> GHOST_SPAWN_EGG = register("ghost_spawn_egg", properties -> new SpawnEggItem(WhisperingWoodsModModEntities.GHOST.get(), properties));
	public static final DeferredItem<Item> HAUNTED_TULIP = block(WhisperingWoodsModModBlocks.HAUNTED_TULIP, new Item.Properties().fireResistant());
	public static final DeferredItem<Item> GHOST_WORLD = register("ghost_world", GhostWorldItem::new);
	public static final DeferredItem<Item> OWL_SPAWN_EGG = register("owl_spawn_egg", properties -> new SpawnEggItem(WhisperingWoodsModModEntities.OWL.get(), properties));
	public static final DeferredItem<Item> GNOME_SPAWN_EGG = register("gnome_spawn_egg", properties -> new SpawnEggItem(WhisperingWoodsModModEntities.GNOME.get(), properties));
	public static final DeferredItem<Item> GNOME_ARMOR_HELMET = register("gnome_armor_helmet", GnomeArmorItem.Helmet::new);
	public static final DeferredItem<Item> GNOME_ARMOR_BOOTS = register("gnome_armor_boots", GnomeArmorItem.Boots::new);
	public static final DeferredItem<Item> GNOME_PICKAXE = register("gnome_pickaxe", GnomePickaxeItem::new);
	public static final DeferredItem<Item> GHOST_FISH_SPAWN_EGG = register("ghost_fish_spawn_egg", properties -> new SpawnEggItem(WhisperingWoodsModModEntities.GHOST_FISH.get(), properties));
	public static final DeferredItem<Item> SALT_WIRE = block(WhisperingWoodsModModBlocks.SALT_WIRE);
	public static final DeferredItem<Item> PLANT_2 = block(WhisperingWoodsModModBlocks.PLANT_2);
	public static final DeferredItem<Item> VIOLET_LOG = block(WhisperingWoodsModModBlocks.VIOLET_LOG);
	public static final DeferredItem<Item> VIOLET_WOOD = block(WhisperingWoodsModModBlocks.VIOLET_WOOD);
	public static final DeferredItem<Item> STRIPPED_VIOLET_LOG = block(WhisperingWoodsModModBlocks.STRIPPED_VIOLET_LOG);
	public static final DeferredItem<Item> STRIPPED_VIOLET_WOOD = block(WhisperingWoodsModModBlocks.STRIPPED_VIOLET_WOOD);
	public static final DeferredItem<Item> VIOLET_PLANKS = block(WhisperingWoodsModModBlocks.VIOLET_PLANKS);
	public static final DeferredItem<Item> VIOLET_STAIRS = block(WhisperingWoodsModModBlocks.VIOLET_STAIRS);
	public static final DeferredItem<Item> TESTLOG = block(WhisperingWoodsModModBlocks.TESTLOG);
	public static final DeferredItem<Item> VIOLET_LEAVES = block(WhisperingWoodsModModBlocks.VIOLET_LEAVES);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}