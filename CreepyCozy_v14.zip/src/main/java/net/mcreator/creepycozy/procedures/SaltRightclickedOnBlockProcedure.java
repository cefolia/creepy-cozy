package net.mcreator.creepycozy.procedures;

public class SaltRightclickedOnBlockProcedure {
	public static void execute() {
	}
}