/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.creepycozy.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

import net.mcreator.creepycozy.CreepyCozyMod;

public class CreepyCozyModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(Registries.SOUND_EVENT, CreepyCozyMod.MODID);
	public static final DeferredHolder<SoundEvent, SoundEvent> ENTITY_GNOME_STEP = REGISTRY.register("entity.gnome.step", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("creepy_cozy", "entity.gnome.step")));
	public static final DeferredHolder<SoundEvent, SoundEvent> MUSIC_WHISPERING_WOODS = REGISTRY.register("music.whispering_woods",
			() -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("creepy_cozy", "music.whispering_woods")));
}