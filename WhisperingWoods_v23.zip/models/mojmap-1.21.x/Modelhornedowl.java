// Made with Blockbench 5.0.2
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports

public class Modelhornedowl<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
			new ResourceLocation("modid", "hornedowl"), "main");
	private final ModelPart body;
	private final ModelPart lower_body;
	private final ModelPart tail;
	private final ModelPart lowertail;
	private final ModelPart head;
	private final ModelPart beak;
	private final ModelPart r_horn;
	private final ModelPart l_horn;
	private final ModelPart r_wing;
	private final ModelPart r_lowerwing;
	private final ModelPart l_wing;
	private final ModelPart l_lowerwing;
	private final ModelPart legs;
	private final ModelPart l_leg;
	private final ModelPart l_lowerleg;
	private final ModelPart l_foot;
	private final ModelPart r_leg;
	private final ModelPart r_lowerleg;
	private final ModelPart r_foot;

	public Modelhornedowl(ModelPart root) {
		this.body = root.getChild("body");
		this.lower_body = this.body.getChild("lower_body");
		this.tail = this.body.getChild("tail");
		this.lowertail = this.tail.getChild("lowertail");
		this.head = this.body.getChild("head");
		this.beak = this.head.getChild("beak");
		this.r_horn = this.head.getChild("r_horn");
		this.l_horn = this.head.getChild("l_horn");
		this.r_wing = this.body.getChild("r_wing");
		this.r_lowerwing = this.r_wing.getChild("r_lowerwing");
		this.l_wing = this.body.getChild("l_wing");
		this.l_lowerwing = this.l_wing.getChild("l_lowerwing");
		this.legs = this.body.getChild("legs");
		this.l_leg = this.legs.getChild("l_leg");
		this.l_lowerleg = this.l_leg.getChild("l_lowerleg");
		this.l_foot = this.l_leg.getChild("l_foot");
		this.r_leg = this.l_leg.getChild("r_leg");
		this.r_lowerleg = this.r_leg.getChild("r_lowerleg");
		this.r_foot = this.r_leg.getChild("r_foot");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition body = partdefinition.addOrReplaceChild("body", CubeListBuilder.create(),
				PartPose.offset(0.0F, 14.0F, 4.0F));

		PartDefinition upperbody_r1 = body.addOrReplaceChild("upperbody_r1",
				CubeListBuilder.create().texOffs(0, 0).addBox(-5.51F, -7.01F, -2.51F, 8.02F, 7.02F, 6.77F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(1.0F, 3.0F, -2.1F, -0.0873F, 0.0F, 0.0F));

		PartDefinition lower_body = body.addOrReplaceChild("lower_body", CubeListBuilder.create(),
				PartPose.offset(1.0F, 3.0F, -2.1F));

		PartDefinition lowerbody_r1 = lower_body.addOrReplaceChild("lowerbody_r1",
				CubeListBuilder.create().texOffs(0, 14).addBox(-5.0F, -6.0F, -2.0F, 7.0F, 7.0F, 6.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 1.0F, -1.9F, -0.3491F, 0.0F, 0.0F));

		PartDefinition tail = body.addOrReplaceChild("tail", CubeListBuilder.create(),
				PartPose.offset(0.0F, 2.0F, -4.0F));

		PartDefinition tail_r1 = tail
				.addOrReplaceChild("tail_r1",
						CubeListBuilder.create().texOffs(30, 0).addBox(-4.25F, -2.0F, 0.0F, 5.5F, 4.0F, 1.75F,
								new CubeDeformation(0.0F)),
						PartPose.offsetAndRotation(1.0F, 3.0F, -2.3F, -0.48F, 0.0F, 0.0F));

		PartDefinition lowertail = tail.addOrReplaceChild("lowertail", CubeListBuilder.create(),
				PartPose.offset(0.0F, 0.0F, 0.0F));

		PartDefinition lowertail_r1 = lowertail.addOrReplaceChild("lowertail_r1",
				CubeListBuilder.create().texOffs(38, 25).addBox(-3.25F, -2.0F, 0.0F, 3.5F, 3.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(1.0F, 5.2F, -3.5F, -0.6545F, 0.0F, 0.0F));

		PartDefinition head = body.addOrReplaceChild("head", CubeListBuilder.create().texOffs(26, 14).addBox(-3.625F,
				-2.6004F, -4.3098F, 7.0F, 5.0F, 6.0F, new CubeDeformation(0.0F)),
				PartPose.offset(-0.375F, -6.0335F, 0.8967F));

		PartDefinition beak = head.addOrReplaceChild("beak", CubeListBuilder.create(),
				PartPose.offset(-0.125F, 0.0335F, 2.1033F));

		PartDefinition beak_r1 = beak.addOrReplaceChild("beak_r1",
				CubeListBuilder.create().texOffs(22, 27).addBox(-1.45F, -2.0F, 1.0F, 0.9F, 1.675F, 0.925F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(1.0F, 1.3F, -1.7F, -0.1309F, 0.0F, 0.0F));

		PartDefinition r_horn = head.addOrReplaceChild("r_horn", CubeListBuilder.create(),
				PartPose.offset(3.525F, -3.5189F, -0.8593F));

		PartDefinition lefthorn_r1 = r_horn
				.addOrReplaceChild("lefthorn_r1",
						CubeListBuilder.create().texOffs(16, 37).addBox(-0.25F, -1.5F, -1.0F, 0.5F, 3.0F, 2.0F,
								new CubeDeformation(0.0F)),
						PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.5672F, 0.0F, 0.0F));

		PartDefinition l_horn = head.addOrReplaceChild("l_horn", CubeListBuilder.create(),
				PartPose.offset(-3.75F, -3.5189F, -0.8593F));

		PartDefinition lefthorn_r2 = l_horn
				.addOrReplaceChild("lefthorn_r2",
						CubeListBuilder.create().texOffs(32, 40).addBox(-0.25F, -1.5F, -1.0F, 0.5F, 3.0F, 2.0F,
								new CubeDeformation(0.0F)),
						PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.5672F, 0.0F, 0.0F));

		PartDefinition r_wing = body.addOrReplaceChild("r_wing", CubeListBuilder.create(),
				PartPose.offset(-5.0F, -3.5F, -2.25F));

		PartDefinition upperwingright_r1 = r_wing.addOrReplaceChild("upperwingright_r1",
				CubeListBuilder.create().texOffs(26, 25).addBox(-0.16F, -0.835F, -1.235F, 0.895F, 5.02F, 5.22F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.325F, 0.3F, -0.75F, -0.2487F, 0.0F, 0.0F));

		PartDefinition r_lowerwing = r_wing.addOrReplaceChild("r_lowerwing", CubeListBuilder.create(),
				PartPose.offset(0.1375F, 4.4012F, -0.5831F));

		PartDefinition lowerwingright_r1 = r_lowerwing.addOrReplaceChild("lowerwingright_r1",
				CubeListBuilder.create().texOffs(12, 27).addBox(-0.2625F, -1.5148F, -2.5577F, 0.525F, 6.45F, 3.975F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, -0.5F, 1.0F, -0.2662F, 0.0F, 0.0F));

		PartDefinition l_wing = body.addOrReplaceChild("l_wing", CubeListBuilder.create(),
				PartPose.offset(4.0F, -3.75F, -2.0F));

		PartDefinition upperwingleft_r1 = l_wing.addOrReplaceChild("upperwingleft_r1",
				CubeListBuilder.create().texOffs(0, 27).addBox(-0.4475F, -4.3254F, -3.5869F, 0.895F, 5.02F, 5.22F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.0375F, 4.5119F, 0.4204F, -0.2487F, 0.0F, 0.0F));

		PartDefinition l_lowerwing = l_wing.addOrReplaceChild("l_lowerwing", CubeListBuilder.create(),
				PartPose.offset(-0.1125F, 4.6512F, -0.8331F));

		PartDefinition lowerwingleft_r1 = l_lowerwing.addOrReplaceChild("lowerwingleft_r1",
				CubeListBuilder.create().texOffs(22, 35).addBox(0.2F, 1.725F, -0.75F, 0.525F, 6.45F, 3.975F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.4625F, -4.1012F, 0.1081F, -0.2662F, 0.0F, 0.0F));

		PartDefinition legs = body.addOrReplaceChild("legs", CubeListBuilder.create(),
				PartPose.offset(0.0F, 0.0F, 0.0F));

		PartDefinition l_leg = legs.addOrReplaceChild("l_leg", CubeListBuilder.create(),
				PartPose.offset(1.359F, 5.3119F, -2.6197F));

		PartDefinition l_lowerleg = l_leg.addOrReplaceChild("l_lowerleg", CubeListBuilder.create(),
				PartPose.offset(-0.134F, 1.6869F, -0.3992F));

		PartDefinition lowerleftleg_r1 = l_lowerleg.addOrReplaceChild(
				"lowerleftleg_r1", CubeListBuilder.create().texOffs(38, 29).addBox(-0.885F, -1.8725F, -0.835F, 1.77F,
						3.745F, 1.67F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 1.0F, 1.0F, 0.5192F, 0.0F, 0.0F));

		PartDefinition l_foot = l_leg.addOrReplaceChild("l_foot", CubeListBuilder.create(),
				PartPose.offset(0.134F, 4.3131F, 0.3992F));

		PartDefinition leftfoot_r1 = l_foot.addOrReplaceChild(
				"leftfoot_r1", CubeListBuilder.create().texOffs(8, 37).addBox(-0.6875F, -0.375F, -1.675F, 1.375F, 0.75F,
						3.35F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 2.0F, 0.0F, 0.1004F, 0.0F));

		PartDefinition r_leg = l_leg.addOrReplaceChild("r_leg", CubeListBuilder.create(),
				PartPose.offset(-3.6778F, -0.3687F, 0.3167F));

		PartDefinition upperleftleg_r1 = r_leg.addOrReplaceChild("upperleftleg_r1",
				CubeListBuilder.create().texOffs(30, 6)
						.addBox(-1.25F, -1.625F, -1.075F, 2.5F, 3.25F, 2.15F, new CubeDeformation(0.0F)).texOffs(32, 35)
						.addBox(-4.725F, -1.625F, -1.075F, 2.5F, 3.25F, 2.15F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(3.4187F, 0.9432F, -0.303F, -0.3447F, 0.0F, 0.0F));

		PartDefinition r_lowerleg = r_leg.addOrReplaceChild("r_lowerleg", CubeListBuilder.create(),
				PartPose.offset(-0.2062F, 2.0556F, -0.7158F));

		PartDefinition lowerrightleg_r1 = r_lowerleg.addOrReplaceChild(
				"lowerrightleg_r1", CubeListBuilder.create().texOffs(40, 6).addBox(-0.885F, -1.8725F, -0.835F, 1.77F,
						3.745F, 1.67F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 1.0F, 1.0F, 0.5192F, 0.0F, 0.0F));

		PartDefinition r_foot = r_leg.addOrReplaceChild("r_foot", CubeListBuilder.create(),
				PartPose.offset(-0.2421F, 4.6818F, 0.3406F));

		PartDefinition rightfoot_r1 = r_foot.addOrReplaceChild(
				"rightfoot_r1", CubeListBuilder.create().texOffs(0, 37).addBox(-0.6875F, -0.375F, -1.675F, 1.375F,
						0.75F, 3.35F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 2.0F, 0.0F, -0.192F, 0.0F));

		return LayerDefinition.create(meshdefinition, 64, 64);
	}

	@Override
	public void setupAnim(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
			float headPitch) {

	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay,
			float red, float green, float blue, float alpha) {
		body.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}
}