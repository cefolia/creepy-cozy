/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.creepycozy.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.creepycozy.client.renderer.OwlRenderer;
import net.mcreator.creepycozy.client.renderer.GnomeRenderer;
import net.mcreator.creepycozy.client.renderer.GhostRenderer;
import net.mcreator.creepycozy.client.renderer.GhostFishRenderer;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class CreepyCozyModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(CreepyCozyModEntities.GHOST.get(), GhostRenderer::new);
		event.registerEntityRenderer(CreepyCozyModEntities.OWL.get(), OwlRenderer::new);
		event.registerEntityRenderer(CreepyCozyModEntities.GNOME.get(), GnomeRenderer::new);
		event.registerEntityRenderer(CreepyCozyModEntities.GHOST_FISH.get(), GhostFishRenderer::new);
	}
}