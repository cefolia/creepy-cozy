/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.creepycozy.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.creepycozy.block.VioletWoodBlock;
import net.mcreator.creepycozy.block.VioletLogBlock;
import net.mcreator.creepycozy.block.StrippedVioletWoodBlock;
import net.mcreator.creepycozy.block.StrippedVioletLogBlock;
import net.mcreator.creepycozy.block.SaltWireBlock;
import net.mcreator.creepycozy.block.Plant2Block;
import net.mcreator.creepycozy.block.HauntedTulipBlock;
import net.mcreator.creepycozy.block.GhostWorldPortalBlock;
import net.mcreator.creepycozy.CreepyCozyMod;

import java.util.function.Function;

public class CreepyCozyModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(CreepyCozyMod.MODID);
	public static final DeferredBlock<Block> HAUNTED_TULIP = register("haunted_tulip", HauntedTulipBlock::new);
	public static final DeferredBlock<Block> GHOST_WORLD_PORTAL = register("ghost_world_portal", GhostWorldPortalBlock::new);
	public static final DeferredBlock<Block> SALT_WIRE = register("salt_wire", SaltWireBlock::new);
	public static final DeferredBlock<Block> PLANT_2 = register("plant_2", Plant2Block::new);
	public static final DeferredBlock<Block> VIOLET_LOG = register("violet_log", VioletLogBlock::new);
	public static final DeferredBlock<Block> VIOLET_WOOD = register("violet_wood", VioletWoodBlock::new);
	public static final DeferredBlock<Block> STRIPPED_VIOLET_LOG = register("stripped_violet_log", StrippedVioletLogBlock::new);
	public static final DeferredBlock<Block> STRIPPED_VIOLET_WOOD = register("stripped_violet_wood", StrippedVioletWoodBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}