/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.creepycozy.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.creepycozy.CreepyCozyMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class CreepyCozyModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, CreepyCozyMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(CreepyCozyModItems.GHOST_SPAWN_EGG.get());
			tabData.accept(CreepyCozyModItems.OWL_SPAWN_EGG.get());
			tabData.accept(CreepyCozyModItems.GNOME_SPAWN_EGG.get());
			tabData.accept(CreepyCozyModItems.GHOST_FISH_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(CreepyCozyModBlocks.HAUNTED_TULIP.get().asItem());
			tabData.accept(CreepyCozyModBlocks.PLANT_2.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(CreepyCozyModItems.GHOST_WORLD.get());
			tabData.accept(CreepyCozyModItems.GNOME_PICKAXE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(CreepyCozyModItems.GNOME_ARMOR_HELMET.get());
			tabData.accept(CreepyCozyModItems.GNOME_ARMOR_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(CreepyCozyModBlocks.SALT_WIRE.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(CreepyCozyModBlocks.VIOLET_LOG.get().asItem());
			tabData.accept(CreepyCozyModBlocks.VIOLET_WOOD.get().asItem());
			tabData.accept(CreepyCozyModBlocks.STRIPPED_VIOLET_LOG.get().asItem());
			tabData.accept(CreepyCozyModBlocks.STRIPPED_VIOLET_WOOD.get().asItem());
		}
	}
}