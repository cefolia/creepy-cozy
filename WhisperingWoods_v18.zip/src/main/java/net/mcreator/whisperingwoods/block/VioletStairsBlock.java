package net.mcreator.whisperingwoods.block;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Blocks;

public class VioletStairsBlock extends StairBlock {
	public VioletStairsBlock(BlockBehaviour.Properties properties) {
		super(Blocks.AIR.defaultBlockState(), properties.sound(SoundType.WOOD).strength(2f, 3f).ignitedByLava());
	}

	@Override
	public float getExplosionResistance() {
		return 3f;
	}

	@Override
	public int getLightBlock(BlockState state) {
		return 0;
	}
}