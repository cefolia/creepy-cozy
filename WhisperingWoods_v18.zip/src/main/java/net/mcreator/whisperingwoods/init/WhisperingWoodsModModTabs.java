/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.whisperingwoods.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.whisperingwoods.WhisperingWoodsModMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class WhisperingWoodsModModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, WhisperingWoodsModMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(WhisperingWoodsModModItems.GHOST_SPAWN_EGG.get());
			tabData.accept(WhisperingWoodsModModItems.OWL_SPAWN_EGG.get());
			tabData.accept(WhisperingWoodsModModItems.GNOME_SPAWN_EGG.get());
			tabData.accept(WhisperingWoodsModModItems.GHOST_FISH_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(WhisperingWoodsModModBlocks.HAUNTED_TULIP.get().asItem());
			tabData.accept(WhisperingWoodsModModBlocks.PLANT_2.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(WhisperingWoodsModModItems.GHOST_WORLD.get());
			tabData.accept(WhisperingWoodsModModItems.GNOME_PICKAXE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(WhisperingWoodsModModItems.GNOME_ARMOR_HELMET.get());
			tabData.accept(WhisperingWoodsModModItems.GNOME_ARMOR_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(WhisperingWoodsModModBlocks.SALT_WIRE.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(WhisperingWoodsModModBlocks.VIOLET_LOG.get().asItem());
			tabData.accept(WhisperingWoodsModModBlocks.VIOLET_WOOD.get().asItem());
			tabData.accept(WhisperingWoodsModModBlocks.STRIPPED_VIOLET_LOG.get().asItem());
			tabData.accept(WhisperingWoodsModModBlocks.STRIPPED_VIOLET_WOOD.get().asItem());
			tabData.accept(WhisperingWoodsModModBlocks.VIOLET_PLANKS.get().asItem());
		}
	}
}