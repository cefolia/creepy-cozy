/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.whisperingwoods.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

import net.mcreator.whisperingwoods.WhisperingWoodsModMod;

public class WhisperingWoodsModModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(Registries.SOUND_EVENT, WhisperingWoodsModMod.MODID);
	public static final DeferredHolder<SoundEvent, SoundEvent> ENTITY_GNOME_STEP = REGISTRY.register("entity.gnome.step", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("whispering_woods_mod", "entity.gnome.step")));
	public static final DeferredHolder<SoundEvent, SoundEvent> MUSIC_WHISPERING_WOODS = REGISTRY.register("music.whispering_woods",
			() -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("whispering_woods_mod", "music.whispering_woods")));
}