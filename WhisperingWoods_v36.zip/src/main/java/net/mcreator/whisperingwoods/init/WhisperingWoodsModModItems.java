/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.whisperingwoods.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.DoubleHighBlockItem;
import net.minecraft.world.item.BlockItem;

import net.mcreator.whisperingwoods.item.GnomePickaxeItem;
import net.mcreator.whisperingwoods.item.GnomeArmorItem;
import net.mcreator.whisperingwoods.item.GhostWorldItem;
import net.mcreator.whisperingwoods.item.AcornItem;
import net.mcreator.whisperingwoods.WhisperingWoodsModMod;

import java.util.function.Function;

public class WhisperingWoodsModModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(WhisperingWoodsModMod.MODID);
	public static final DeferredItem<Item> GHOST_SPAWN_EGG = register("ghost_spawn_egg", properties -> new SpawnEggItem(WhisperingWoodsModModEntities.GHOST.get(), properties));
	public static final DeferredItem<Item> HAUNTED_TULIP = block(WhisperingWoodsModModBlocks.HAUNTED_TULIP, new Item.Properties().fireResistant());
	public static final DeferredItem<Item> GHOST_WORLD = register("ghost_world", GhostWorldItem::new);
	public static final DeferredItem<Item> BARN_OWL_SPAWN_EGG = register("barn_owl_spawn_egg", properties -> new SpawnEggItem(WhisperingWoodsModModEntities.BARN_OWL.get(), properties));
	public static final DeferredItem<Item> GNOME_SPAWN_EGG = register("gnome_spawn_egg", properties -> new SpawnEggItem(WhisperingWoodsModModEntities.GNOME.get(), properties));
	public static final DeferredItem<Item> GNOME_ARMOR_HELMET = register("gnome_armor_helmet", GnomeArmorItem.Helmet::new);
	public static final DeferredItem<Item> GNOME_ARMOR_BOOTS = register("gnome_armor_boots", GnomeArmorItem.Boots::new);
	public static final DeferredItem<Item> GNOME_PICKAXE = register("gnome_pickaxe", GnomePickaxeItem::new);
	public static final DeferredItem<Item> GHOST_FISH_SPAWN_EGG = register("ghost_fish_spawn_egg", properties -> new SpawnEggItem(WhisperingWoodsModModEntities.GHOST_FISH.get(), properties));
	public static final DeferredItem<Item> VIOLET_LOG = block(WhisperingWoodsModModBlocks.VIOLET_LOG);
	public static final DeferredItem<Item> VIOLET_WOOD = block(WhisperingWoodsModModBlocks.VIOLET_WOOD);
	public static final DeferredItem<Item> STRIPPED_VIOLET_LOG = block(WhisperingWoodsModModBlocks.STRIPPED_VIOLET_LOG);
	public static final DeferredItem<Item> STRIPPED_VIOLET_WOOD = block(WhisperingWoodsModModBlocks.STRIPPED_VIOLET_WOOD);
	public static final DeferredItem<Item> VIOLET_PLANKS = block(WhisperingWoodsModModBlocks.VIOLET_PLANKS);
	public static final DeferredItem<Item> VIOLET_STAIRS = block(WhisperingWoodsModModBlocks.VIOLET_STAIRS);
	public static final DeferredItem<Item> VIOLET_LEAVES = block(WhisperingWoodsModModBlocks.VIOLET_LEAVES);
	public static final DeferredItem<Item> VIOLET_SLAB = block(WhisperingWoodsModModBlocks.VIOLET_SLAB);
	public static final DeferredItem<Item> HAUNTED_CORNFLOWER = block(WhisperingWoodsModModBlocks.HAUNTED_CORNFLOWER);
	public static final DeferredItem<Item> VIOLET_FENCE = block(WhisperingWoodsModModBlocks.VIOLET_FENCE);
	public static final DeferredItem<Item> VIOLET_FENCE_GATE = block(WhisperingWoodsModModBlocks.VIOLET_FENCE_GATE);
	public static final DeferredItem<Item> VIOLET_DOOR = doubleBlock(WhisperingWoodsModModBlocks.VIOLET_DOOR, new Item.Properties().fireResistant());
	public static final DeferredItem<Item> VIOLET_TRAPDOOR = block(WhisperingWoodsModModBlocks.VIOLET_TRAPDOOR, new Item.Properties().fireResistant());
	public static final DeferredItem<Item> VIOLET_PRESSURE_PLATE = block(WhisperingWoodsModModBlocks.VIOLET_PRESSURE_PLATE, new Item.Properties().fireResistant());
	public static final DeferredItem<Item> VIOLET_BUTTON = block(WhisperingWoodsModModBlocks.VIOLET_BUTTON, new Item.Properties().fireResistant());
	public static final DeferredItem<Item> VIOLET_FIREFLY_BUSH = block(WhisperingWoodsModModBlocks.VIOLET_FIREFLY_BUSH);
	public static final DeferredItem<Item> DEER_SPAWN_EGG = register("deer_spawn_egg", properties -> new SpawnEggItem(WhisperingWoodsModModEntities.DEER.get(), properties));
	public static final DeferredItem<Item> ACORN = register("acorn", AcornItem::new);
	public static final DeferredItem<Item> SHELF_MUSHROOM = block(WhisperingWoodsModModBlocks.SHELF_MUSHROOM);
	public static final DeferredItem<Item> VIOLET_TREE_SAPLING = block(WhisperingWoodsModModBlocks.VIOLET_TREE_SAPLING);
	public static final DeferredItem<Item> HORNED_OWL_SPAWN_EGG = register("horned_owl_spawn_egg", properties -> new SpawnEggItem(WhisperingWoodsModModEntities.HORNED_OWL.get(), properties));
	public static final DeferredItem<Item> GNOME_HAT = block(WhisperingWoodsModModBlocks.GNOME_HAT);
	public static final DeferredItem<Item> HAUNTED_DANDELION = block(WhisperingWoodsModModBlocks.HAUNTED_DANDELION, new Item.Properties().fireResistant());
	public static final DeferredItem<Item> HAUNTED_WILDFLOWER = block(WhisperingWoodsModModBlocks.HAUNTED_WILDFLOWER, new Item.Properties().fireResistant());

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}

	private static DeferredItem<Item> doubleBlock(DeferredHolder<Block, Block> block) {
		return doubleBlock(block, new Item.Properties());
	}

	private static DeferredItem<Item> doubleBlock(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new DoubleHighBlockItem(block.get(), prop), properties);
	}
}