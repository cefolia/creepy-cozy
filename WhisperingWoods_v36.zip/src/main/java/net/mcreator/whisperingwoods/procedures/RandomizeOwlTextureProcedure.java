package net.mcreator.whisperingwoods.procedures;

import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;

import net.mcreator.whisperingwoods.entity.OwlEntity;

import javax.annotation.Nullable;

@EventBusSubscriber
public class RandomizeOwlTextureProcedure {
	@SubscribeEvent
	public static void onEntitySpawned(EntityJoinLevelEvent event) {
		execute(event, event.getEntity());
	}

	public static void execute(Entity entity) {
		execute(null, entity);
	}

	private static void execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof OwlEntity) {
			if (entity.getPersistentData().getBoolean("Rolled") == false) {
				if (entity instanceof OwlEntity _datEntSetI)
					_datEntSetI.getEntityData().set(OwlEntity.DATA_textureID, Mth.nextInt(RandomSource.create(), 1, 2));
				entity.getPersistentData().putBoolean("Rolled", true);
			}
		}
	}
}