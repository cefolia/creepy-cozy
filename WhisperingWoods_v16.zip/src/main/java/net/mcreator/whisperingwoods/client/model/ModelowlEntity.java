package net.mcreator.whisperingwoods.client.model;

import net.minecraft.util.Mth;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.EntityModel;

// Made with Blockbench 5.0.2
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports
public class ModelowlEntity extends EntityModel<LivingEntityRenderState> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath("whispering_woods_mod", "modelowl_entity"), "main");
	public final ModelPart owl;
	public final ModelPart head;
	public final ModelPart tail;
	public final ModelPart beak;
	public final ModelPart wings;
	public final ModelPart left;
	public final ModelPart right;
	public final ModelPart feet;
	public final ModelPart right2;
	public final ModelPart left2;

	public ModelowlEntity(ModelPart root) {
		super(root);
		this.owl = root.getChild("owl");
		this.head = this.owl.getChild("head");
		this.tail = this.owl.getChild("tail");
		this.beak = this.owl.getChild("beak");
		this.wings = this.owl.getChild("wings");
		this.left = this.wings.getChild("left");
		this.right = this.wings.getChild("right");
		this.feet = this.owl.getChild("feet");
		this.right2 = this.feet.getChild("right2");
		this.left2 = this.feet.getChild("left2");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();
		PartDefinition owl = partdefinition.addOrReplaceChild("owl", CubeListBuilder.create(), PartPose.offset(0.5F, 14.25F, -1.0F));
		PartDefinition body_r1 = owl.addOrReplaceChild("body_r1", CubeListBuilder.create().texOffs(0, 0).addBox(-3.0F, -2.0F, -2.0F, 5.0F, 9.0F, 5.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.1745F, 0.0F, 0.0F));
		PartDefinition head = owl.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 14).addBox(-2.0F, -4.0F, -1.0F, 4.0F, 4.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offset(-0.5F, -2.25F, -1.0F));
		PartDefinition tail = owl.addOrReplaceChild("tail", CubeListBuilder.create(), PartPose.offset(0.0F, -0.5F, 0.0F));
		PartDefinition low_tail_r1 = tail.addOrReplaceChild("low_tail_r1", CubeListBuilder.create().texOffs(16, 26).addBox(-1.0F, -2.0F, 0.0F, 3.0F, 4.0F, 1.0F, new CubeDeformation(0.02F)),
				PartPose.offsetAndRotation(-1.0F, 8.5F, 4.75F, 0.5672F, 0.0F, 0.0F));
		PartDefinition tail_r1 = tail.addOrReplaceChild("tail_r1", CubeListBuilder.create().texOffs(26, 12).addBox(-3.0F, -2.0F, 0.0F, 5.0F, 3.0F, 1.0F, new CubeDeformation(0.04F)),
				PartPose.offsetAndRotation(0.0F, 7.75F, 4.25F, 0.5672F, 0.0F, 0.0F));
		PartDefinition beak = owl.addOrReplaceChild("beak", CubeListBuilder.create().texOffs(30, 0).addBox(-1.0F, -4.5F, -2.5F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 0.0F, 0.0F));
		PartDefinition wings = owl.addOrReplaceChild("wings", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));
		PartDefinition left = wings.addOrReplaceChild("left", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));
		PartDefinition low_left_wing_r1 = left.addOrReplaceChild("low_left_wing_r1", CubeListBuilder.create().texOffs(0, 22).addBox(-1.0F, -2.0F, 0.0F, 1.0F, 6.0F, 3.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(3.0F, 4.0F, -0.25F, 0.1745F, 0.0F, 0.0F));
		PartDefinition left_wing_r1 = left.addOrReplaceChild("left_wing_r1", CubeListBuilder.create().texOffs(16, 14).addBox(-1.0F, -2.0F, -1.0F, 1.0F, 8.0F, 4.0F, new CubeDeformation(0.1F)),
				PartPose.offsetAndRotation(3.0F, 0.0F, -0.5F, 0.1745F, 0.0F, 0.0F));
		PartDefinition right = wings.addOrReplaceChild("right", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));
		PartDefinition low_right_wing_r1 = right.addOrReplaceChild("low_right_wing_r1", CubeListBuilder.create().texOffs(8, 22).addBox(-1.0F, -2.0F, 0.0F, 1.0F, 6.0F, 3.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-3.0F, 4.0F, -0.25F, 0.1745F, 0.0F, 0.0F));
		PartDefinition right_wing_r1 = right.addOrReplaceChild("right_wing_r1", CubeListBuilder.create().texOffs(20, 0).addBox(-1.0F, -2.0F, -1.0F, 1.0F, 8.0F, 4.0F, new CubeDeformation(0.1F)),
				PartPose.offsetAndRotation(-3.0F, 0.0F, -0.5F, 0.1745F, 0.0F, 0.0F));
		PartDefinition feet = owl.addOrReplaceChild("feet", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));
		PartDefinition right2 = feet.addOrReplaceChild("right2",
				CubeListBuilder.create().texOffs(26, 16).addBox(-2.0F, 5.75F, 0.75F, 1.0F, 4.0F, 1.0F, new CubeDeformation(0.01F)).texOffs(24, 26).addBox(-2.0F, 8.75F, -0.25F, 1.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 0.0F, 0.0F));
		PartDefinition left2 = feet.addOrReplaceChild("left2",
				CubeListBuilder.create().texOffs(26, 21).addBox(-0.25F, 5.75F, 0.75F, 1.0F, 4.0F, 1.0F, new CubeDeformation(0.01F)).texOffs(24, 29).addBox(-0.25F, 8.75F, -0.25F, 1.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 0.0F, 0.0F));
		return LayerDefinition.create(meshdefinition, 64, 64);
	}

	public void setupAnim(LivingEntityRenderState state) {
		float limbSwing = state.walkAnimationPos;
		float limbSwingAmount = state.walkAnimationSpeed;
		float ageInTicks = state.ageInTicks;
		float netHeadYaw = state.yRot;
		float headPitch = state.xRot;

		this.feet.zRot = Mth.cos(limbSwing * 1.0F) * 1.0F * limbSwingAmount;
		this.owl.yRot = netHeadYaw / (180F / (float) Math.PI);
		this.owl.xRot = headPitch / (180F / (float) Math.PI);
		this.left.yRot = Mth.cos(limbSwing * 0.6662F) * limbSwingAmount;
		this.right2.zRot = Mth.cos(limbSwing * 0.6662F + (float) Math.PI) * limbSwingAmount;
		this.left2.zRot = Mth.cos(limbSwing * 0.6662F) * limbSwingAmount;
		this.right.yRot = Mth.cos(limbSwing * 0.6662F + (float) Math.PI) * limbSwingAmount;
	}
}