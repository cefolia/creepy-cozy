package net.mcreator.whisperingwoods.block;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.block.state.properties.RedstoneSide;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.BlockPos;

import net.mcreator.whisperingwoods.procedures.SaltWireBlockIsPlacedByProcedure;
import net.mcreator.whisperingwoods.procedures.GhostWalksOnSaltProcedure;

public class SaltWireBlock extends Block {
	public static final EnumProperty<RedstoneSide> NORTH_REDSTONE = BlockStateProperties.NORTH_REDSTONE;
	public static final EnumProperty<RedstoneSide> SOUTH_REDSTONE = BlockStateProperties.SOUTH_REDSTONE;
	public static final EnumProperty<RedstoneSide> WEST_REDSTONE = BlockStateProperties.WEST_REDSTONE;
	public static final EnumProperty<RedstoneSide> EAST_REDSTONE = BlockStateProperties.EAST_REDSTONE;

	public SaltWireBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.GRAVEL).strength(1f, 10f).noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(NORTH_REDSTONE, NORTH_REDSTONE.getValue("none").get()).setValue(SOUTH_REDSTONE, SOUTH_REDSTONE.getValue("none").get()).setValue(WEST_REDSTONE, WEST_REDSTONE.getValue("none").get())
				.setValue(EAST_REDSTONE, EAST_REDSTONE.getValue("none").get()));
	}

	@Override
	public int getLightBlock(BlockState state) {
		return 1;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		super.createBlockStateDefinition(builder);
		builder.add(NORTH_REDSTONE, SOUTH_REDSTONE, WEST_REDSTONE, EAST_REDSTONE);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return super.getStateForPlacement(context).setValue(NORTH_REDSTONE, NORTH_REDSTONE.getValue("none").get()).setValue(SOUTH_REDSTONE, SOUTH_REDSTONE.getValue("none").get()).setValue(WEST_REDSTONE, WEST_REDSTONE.getValue("none").get())
				.setValue(EAST_REDSTONE, EAST_REDSTONE.getValue("none").get());
	}

	@Override
	public void entityInside(BlockState blockstate, Level world, BlockPos pos, Entity entity) {
		super.entityInside(blockstate, world, pos, entity);
		GhostWalksOnSaltProcedure.execute(pos.getX(), pos.getY(), pos.getZ(), entity);
	}

	@Override
	public void setPlacedBy(Level world, BlockPos pos, BlockState blockstate, LivingEntity entity, ItemStack itemstack) {
		super.setPlacedBy(world, pos, blockstate, entity, itemstack);
		SaltWireBlockIsPlacedByProcedure.execute();
	}
}