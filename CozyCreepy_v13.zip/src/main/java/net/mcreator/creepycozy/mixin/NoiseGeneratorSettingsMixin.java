package net.mcreator.creepycozy.mixin;

import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.levelgen.SurfaceRules;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.core.Holder;

import net.mcreator.creepycozy.init.CreepyCozyModBiomes;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;

@Mixin(NoiseGeneratorSettings.class)
public class NoiseGeneratorSettingsMixin implements CreepyCozyModBiomes.CreepyCozyModNoiseGeneratorSettings {
	@Unique
	private Holder<DimensionType> creepy_cozy_dimensionTypeReference;

	@WrapMethod(method = "surfaceRule")
	public SurfaceRules.RuleSource surfaceRule(Operation<SurfaceRules.RuleSource> original) {
		SurfaceRules.RuleSource retval = original.call();
		if (this.creepy_cozy_dimensionTypeReference != null) {
			retval = CreepyCozyModBiomes.adaptSurfaceRule(retval, this.creepy_cozy_dimensionTypeReference);
		}
		return retval;
	}

	@Override
	public void setcreepy_cozyDimensionTypeReference(Holder<DimensionType> dimensionType) {
		this.creepy_cozy_dimensionTypeReference = dimensionType;
	}
}