/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.creepycozy.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.creepycozy.block.SaltWireBlock;
import net.mcreator.creepycozy.block.HauntedTulipBlock;
import net.mcreator.creepycozy.block.GhostWorldPortalBlock;
import net.mcreator.creepycozy.CreepyCozyMod;

import java.util.function.Function;

public class CreepyCozyModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(CreepyCozyMod.MODID);
	public static final DeferredBlock<Block> HAUNTED_TULIP = register("haunted_tulip", HauntedTulipBlock::new);
	public static final DeferredBlock<Block> GHOST_WORLD_PORTAL = register("ghost_world_portal", GhostWorldPortalBlock::new);
	public static final DeferredBlock<Block> SALT_WIRE = register("salt_wire", SaltWireBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}