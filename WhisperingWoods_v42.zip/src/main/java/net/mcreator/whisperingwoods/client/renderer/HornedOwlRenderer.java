package net.mcreator.whisperingwoods.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelPart;

import net.mcreator.whisperingwoods.entity.HornedOwlEntity;
import net.mcreator.whisperingwoods.client.model.animations.owlEntityAnimation;
import net.mcreator.whisperingwoods.client.model.animations.hornedowlAnimation;
import net.mcreator.whisperingwoods.client.model.Modelhornedowl;

import com.mojang.blaze3d.vertex.PoseStack;

public class HornedOwlRenderer extends MobRenderer<HornedOwlEntity, LivingEntityRenderState, Modelhornedowl> {
	private HornedOwlEntity entity = null;

	public HornedOwlRenderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedModel(context.bakeLayer(Modelhornedowl.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public LivingEntityRenderState createRenderState() {
		return new LivingEntityRenderState();
	}

	@Override
	public void extractRenderState(HornedOwlEntity entity, LivingEntityRenderState state, float partialTicks) {
		super.extractRenderState(entity, state, partialTicks);
		this.entity = entity;
		if (this.model instanceof AnimatedModel) {
			((AnimatedModel) this.model).setEntity(entity);
		}
	}

	@Override
	public ResourceLocation getTextureLocation(LivingEntityRenderState state) {
		return ResourceLocation.parse("whispering_woods_mod:textures/entities/horned_owl_texture_01.png");
	}

	@Override
	protected void scale(LivingEntityRenderState state, PoseStack poseStack) {
		poseStack.scale(entity.getAgeScale(), entity.getAgeScale(), entity.getAgeScale());
	}

	private static final class AnimatedModel extends Modelhornedowl {
		private HornedOwlEntity entity = null;

		public AnimatedModel(ModelPart root) {
			super(root);
		}

		public void setEntity(HornedOwlEntity entity) {
			this.entity = entity;
		}

		@Override
		public void setupAnim(LivingEntityRenderState state) {
			this.root().getAllParts().forEach(ModelPart::resetPose);
			this.animateWalk(owlEntityAnimation.animation, state.walkAnimationPos, state.walkAnimationSpeed, 0.5f, 1f);
			this.animate(entity.animationState1, hornedowlAnimation.flying, state.ageInTicks, 1f);
			super.setupAnim(state);
		}
	}
}