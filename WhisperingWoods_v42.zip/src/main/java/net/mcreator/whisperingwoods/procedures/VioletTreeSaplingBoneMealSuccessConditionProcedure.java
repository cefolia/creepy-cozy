package net.mcreator.whisperingwoods.procedures;

import net.minecraft.world.level.LevelAccessor;

public class VioletTreeSaplingBoneMealSuccessConditionProcedure {
	public static boolean execute(LevelAccessor world, double x, double y, double z) {
		double random = 0;
		if (Math.random() < 0.35) {
			return VioletTreeFeature0AdditionalGenerationConditionProcedure.execute(world, x, y, z);
		}
		return false;
	}
}