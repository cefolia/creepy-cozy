/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.whisperingwoods.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.whisperingwoods.client.renderer.OwlRenderer;
import net.mcreator.whisperingwoods.client.renderer.HornedOwlRenderer;
import net.mcreator.whisperingwoods.client.renderer.GnomeRenderer;
import net.mcreator.whisperingwoods.client.renderer.GhostRenderer;
import net.mcreator.whisperingwoods.client.renderer.GhostFishRenderer;
import net.mcreator.whisperingwoods.client.renderer.DeerRenderer;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class WhisperingWoodsModModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(WhisperingWoodsModModEntities.GHOST.get(), GhostRenderer::new);
		event.registerEntityRenderer(WhisperingWoodsModModEntities.BARN_OWL.get(), OwlRenderer::new);
		event.registerEntityRenderer(WhisperingWoodsModModEntities.GNOME.get(), GnomeRenderer::new);
		event.registerEntityRenderer(WhisperingWoodsModModEntities.GHOST_FISH.get(), GhostFishRenderer::new);
		event.registerEntityRenderer(WhisperingWoodsModModEntities.DEER.get(), DeerRenderer::new);
		event.registerEntityRenderer(WhisperingWoodsModModEntities.HORNED_OWL.get(), HornedOwlRenderer::new);
	}
}