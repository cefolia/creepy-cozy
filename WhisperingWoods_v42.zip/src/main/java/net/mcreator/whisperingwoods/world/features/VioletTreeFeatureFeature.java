package net.mcreator.whisperingwoods.world.features;

import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.WorldGenLevel;

import net.mcreator.whisperingwoods.world.features.configurations.StructureFeatureConfiguration;
import net.mcreator.whisperingwoods.procedures.VioletTreeFeature0AdditionalGenerationConditionProcedure;

public class VioletTreeFeatureFeature extends StructureFeature {
	public VioletTreeFeatureFeature() {
		super(StructureFeatureConfiguration.CODEC);
	}

	public boolean place(FeaturePlaceContext<StructureFeatureConfiguration> context) {
		WorldGenLevel world = context.level();
		int x = context.origin().getX();
		int y = context.origin().getY();
		int z = context.origin().getZ();
		if (!VioletTreeFeature0AdditionalGenerationConditionProcedure.execute(world, x, y, z))
			return false;
		return super.place(context);
	}
}