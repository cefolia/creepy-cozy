package net.mcreator.whisperingwoods.mixin;

import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.levelgen.SurfaceRules;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.core.Holder;

import net.mcreator.whisperingwoods.init.WhisperingWoodsModModBiomes;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;

@Mixin(NoiseGeneratorSettings.class)
public class NoiseGeneratorSettingsMixin implements WhisperingWoodsModModBiomes.WhisperingWoodsModModNoiseGeneratorSettings {
	@Unique
	private Holder<DimensionType> whispering_woods_mod_dimensionTypeReference;

	@WrapMethod(method = "surfaceRule")
	public SurfaceRules.RuleSource surfaceRule(Operation<SurfaceRules.RuleSource> original) {
		SurfaceRules.RuleSource retval = original.call();
		if (this.whispering_woods_mod_dimensionTypeReference != null) {
			retval = WhisperingWoodsModModBiomes.adaptSurfaceRule(retval, this.whispering_woods_mod_dimensionTypeReference);
		}
		return retval;
	}

	@Override
	public void setwhispering_woods_modDimensionTypeReference(Holder<DimensionType> dimensionType) {
		this.whispering_woods_mod_dimensionTypeReference = dimensionType;
	}
}