package net.mcreator.whisperingwoods.item;

import net.minecraft.world.item.component.Consumables;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;

public class DeerBiscuitItem extends Item {
	public DeerBiscuitItem(Item.Properties properties) {
		super(properties.food((new FoodProperties.Builder()).nutrition(2).saturationModifier(0.3f).build(), Consumables.defaultFood().consumeSeconds(3.2F).build()));
	}
}