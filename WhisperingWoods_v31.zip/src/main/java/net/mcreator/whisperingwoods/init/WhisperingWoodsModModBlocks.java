/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.whisperingwoods.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.whisperingwoods.block.VioletWoodBlock;
import net.mcreator.whisperingwoods.block.VioletTreeSapplingBlock;
import net.mcreator.whisperingwoods.block.VioletTrapdoorBlock;
import net.mcreator.whisperingwoods.block.VioletStairsBlock;
import net.mcreator.whisperingwoods.block.VioletSlabBlock;
import net.mcreator.whisperingwoods.block.VioletPressurePlateBlock;
import net.mcreator.whisperingwoods.block.VioletPlanksBlock;
import net.mcreator.whisperingwoods.block.VioletLogBlock;
import net.mcreator.whisperingwoods.block.VioletLeavesBlock;
import net.mcreator.whisperingwoods.block.VioletFireflyBushBlock;
import net.mcreator.whisperingwoods.block.VioletFenceGateBlock;
import net.mcreator.whisperingwoods.block.VioletFenceBlock;
import net.mcreator.whisperingwoods.block.VioletDoorBlock;
import net.mcreator.whisperingwoods.block.VioletButtonBlock;
import net.mcreator.whisperingwoods.block.StrippedVioletWoodBlock;
import net.mcreator.whisperingwoods.block.StrippedVioletLogBlock;
import net.mcreator.whisperingwoods.block.SaltWireBlock;
import net.mcreator.whisperingwoods.block.HauntedTulipBlock;
import net.mcreator.whisperingwoods.block.HauntedCornflowerBlock;
import net.mcreator.whisperingwoods.block.GhostWorldPortalBlock;
import net.mcreator.whisperingwoods.WhisperingWoodsModMod;

import java.util.function.Function;

public class WhisperingWoodsModModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(WhisperingWoodsModMod.MODID);
	public static final DeferredBlock<Block> HAUNTED_TULIP = register("haunted_tulip", HauntedTulipBlock::new);
	public static final DeferredBlock<Block> GHOST_WORLD_PORTAL = register("ghost_world_portal", GhostWorldPortalBlock::new);
	public static final DeferredBlock<Block> SALT_WIRE = register("salt_wire", SaltWireBlock::new);
	public static final DeferredBlock<Block> VIOLET_LOG = register("violet_log", VioletLogBlock::new);
	public static final DeferredBlock<Block> VIOLET_WOOD = register("violet_wood", VioletWoodBlock::new);
	public static final DeferredBlock<Block> STRIPPED_VIOLET_LOG = register("stripped_violet_log", StrippedVioletLogBlock::new);
	public static final DeferredBlock<Block> STRIPPED_VIOLET_WOOD = register("stripped_violet_wood", StrippedVioletWoodBlock::new);
	public static final DeferredBlock<Block> VIOLET_PLANKS = register("violet_planks", VioletPlanksBlock::new);
	public static final DeferredBlock<Block> VIOLET_STAIRS = register("violet_stairs", VioletStairsBlock::new);
	public static final DeferredBlock<Block> VIOLET_LEAVES = register("violet_leaves", VioletLeavesBlock::new);
	public static final DeferredBlock<Block> VIOLET_SLAB = register("violet_slab", VioletSlabBlock::new);
	public static final DeferredBlock<Block> HAUNTED_CORNFLOWER = register("haunted_cornflower", HauntedCornflowerBlock::new);
	public static final DeferredBlock<Block> VIOLET_FENCE = register("violet_fence", VioletFenceBlock::new);
	public static final DeferredBlock<Block> VIOLET_FENCE_GATE = register("violet_fence_gate", VioletFenceGateBlock::new);
	public static final DeferredBlock<Block> VIOLET_DOOR = register("violet_door", VioletDoorBlock::new);
	public static final DeferredBlock<Block> VIOLET_TRAPDOOR = register("violet_trapdoor", VioletTrapdoorBlock::new);
	public static final DeferredBlock<Block> VIOLET_PRESSURE_PLATE = register("violet_pressure_plate", VioletPressurePlateBlock::new);
	public static final DeferredBlock<Block> VIOLET_BUTTON = register("violet_button", VioletButtonBlock::new);
	public static final DeferredBlock<Block> VIOLET_FIREFLY_BUSH = register("violet_firefly_bush", VioletFireflyBushBlock::new);
	public static final DeferredBlock<Block> VIOLET_TREE_SAPPLING = register("violet_tree_sappling", VioletTreeSapplingBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}