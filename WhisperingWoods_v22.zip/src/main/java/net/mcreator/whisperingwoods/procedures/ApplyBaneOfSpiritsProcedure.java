package net.mcreator.whisperingwoods.procedures;

public class ApplyBaneOfSpiritsProcedure {
	public static void execute() {
	}
}