package net.mcreator.whisperingwoods.client.model;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.EntityModel;

// Made with Blockbench 5.0.2
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports
public class Modelgnome_varient_1_Converted_Converted extends EntityModel<LivingEntityRenderState> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath("whispering_woods_mod", "modelgnome_varient_1_converted_converted"), "main");
	public final ModelPart body;
	public final ModelPart face;
	public final ModelPart hat;
	public final ModelPart beard;
	public final ModelPart right_arm;
	public final ModelPart left_arm;
	public final ModelPart right_leg;
	public final ModelPart left_leg;
	public final ModelPart neck;

	public Modelgnome_varient_1_Converted_Converted(ModelPart root) {
		super(root);
		this.body = root.getChild("body");
		this.face = root.getChild("face");
		this.hat = root.getChild("hat");
		this.beard = root.getChild("beard");
		this.right_arm = root.getChild("right_arm");
		this.left_arm = root.getChild("left_arm");
		this.right_leg = root.getChild("right_leg");
		this.left_leg = root.getChild("left_leg");
		this.neck = root.getChild("neck");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();
		PartDefinition body = partdefinition.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 9).addBox(-12.0F, 0.0F, -1.0F, 6.0F, 2.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(0, 0)
				.addBox(-12.0F, -5.5F, -1.0F, 6.0F, 5.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(20, 5).addBox(-11.5F, -1.0F, -0.5F, 5.0F, 1.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offset(9.0F, 20.0F, -1.0F));
		PartDefinition face = partdefinition.addOrReplaceChild("face",
				CubeListBuilder.create().texOffs(18, 15).addBox(-10.0F, -5.0F, -2.0F, 4.0F, 3.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(4, 29).addBox(-11.0F, -4.0F, -0.25F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(8, 29)
						.addBox(-6.0F, -4.0F, -0.25F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(24, 25).addBox(-9.0F, -4.15F, -2.425F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(12, 30)
						.addBox(-8.5F, -4.45F, -2.7F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offset(8.0F, 16.0F, 0.0F));
		PartDefinition hat = partdefinition.addOrReplaceChild("hat",
				CubeListBuilder.create().texOffs(20, 13).addBox(-10.5F, -5.25F, -2.2F, 5.0F, 1.0F, 1.0F, new CubeDeformation(0.01F)).texOffs(20, 0).addBox(-10.0F, -6.1F, -1.75F, 4.0F, 1.0F, 4.0F, new CubeDeformation(0.01F)).texOffs(12, 27)
						.addBox(-6.5F, -4.25F, -1.25F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(24, 27).addBox(-10.5F, -4.25F, -1.25F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 15)
						.addBox(-10.5F, -5.75F, -1.75F, 5.0F, 2.0F, 4.0F, new CubeDeformation(0.02F)),
				PartPose.offset(8.0F, 16.0F, 0.0F));
		PartDefinition cube_r1 = hat.addOrReplaceChild("cube_r1", CubeListBuilder.create().texOffs(18, 22).addBox(-1.0F, -0.5F, -1.0F, 2.0F, 1.0F, 2.0F, new CubeDeformation(0.01F)),
				PartPose.offsetAndRotation(-8.0F, -6.9297F, 0.5963F, -0.1745F, 0.0F, 0.0F));
		PartDefinition cube_r2 = hat.addOrReplaceChild("cube_r2", CubeListBuilder.create().texOffs(20, 9).addBox(-1.5F, -0.5F, -1.5F, 3.0F, 1.0F, 3.0F, new CubeDeformation(0.01F)),
				PartPose.offsetAndRotation(-8.0F, -6.2594F, 0.3288F, -0.0873F, 0.0F, 0.0F));
		PartDefinition beard = partdefinition.addOrReplaceChild("beard",
				CubeListBuilder.create().texOffs(0, 21).addBox(-11.8F, -0.75F, 1.75F, 4.3F, 1.75F, 1.0F, new CubeDeformation(0.01F)).texOffs(8, 25).addBox(-11.45F, 0.5F, 1.8F, 3.8F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 23)
						.addBox(-11.2F, 1.25F, 1.9F, 3.3F, 2.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(6, 27).addBox(-10.7F, 3.25F, 1.875F, 2.3F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(24, 30)
						.addBox(-10.05F, 4.0F, 1.975F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offset(9.5F, 13.25F, -4.25F));
		PartDefinition beard_3_r1 = beard.addOrReplaceChild("beard_3_r1", CubeListBuilder.create().texOffs(26, 22).addBox(-1.0F, -0.5F, -0.5F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-11.2833F, -0.4313F, 2.35F, 0.0F, 0.0F, 0.1745F));
		PartDefinition beard_2_r1 = beard.addOrReplaceChild("beard_2_r1", CubeListBuilder.create().texOffs(0, 26).addBox(-1.0F, -0.5F, -0.5F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-8.0104F, -0.3891F, 2.35F, 0.0F, 0.0F, -0.1745F));
		PartDefinition right_arm = partdefinition.addOrReplaceChild("right_arm", CubeListBuilder.create(), PartPose.offset(12.9F, 16.5F, -1.0F));
		PartDefinition cube_r3 = right_arm.addOrReplaceChild("cube_r3", CubeListBuilder.create().texOffs(16, 25).addBox(-0.6932F, -3.6508F, -0.75F, 1.0F, 5.0F, 1.5F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-8.9568F, 1.9508F, 0.75F, 0.0F, 0.0F, -0.0873F));
		PartDefinition left_arm = partdefinition.addOrReplaceChild("left_arm", CubeListBuilder.create(), PartPose.offset(8.0F, 16.0F, 0.0F));
		PartDefinition cube_r4 = left_arm.addOrReplaceChild("cube_r4", CubeListBuilder.create().texOffs(20, 25).addBox(-0.3845F, -2.7564F, -0.75F, 1.0F, 5.0F, 1.5F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-11.8655F, 1.5564F, -0.25F, 0.0F, 0.0F, 0.0873F));
		PartDefinition right_leg = partdefinition.addOrReplaceChild("right_leg", CubeListBuilder.create().texOffs(0, 28).addBox(-0.75F, 0.0F, -0.75F, 1.5F, 2.0F, 1.5F, new CubeDeformation(0.0F)), PartPose.offset(1.75F, 22.0F, -0.25F));
		PartDefinition left_leg = partdefinition.addOrReplaceChild("left_leg", CubeListBuilder.create().texOffs(28, 27).addBox(-0.75F, 0.0F, -0.75F, 1.5F, 2.0F, 1.5F, new CubeDeformation(0.0F)), PartPose.offset(-1.75F, 22.0F, -0.25F));
		PartDefinition neck = partdefinition.addOrReplaceChild("neck", CubeListBuilder.create().texOffs(10, 21).addBox(-1.0F, -3.0F, -1.0F, 2.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 16.0F, 0.0F));
		return LayerDefinition.create(meshdefinition, 64, 64);
	}

	public void setupAnim(LivingEntityRenderState state) {
		float limbSwing = state.walkAnimationPos;
		float limbSwingAmount = state.walkAnimationSpeed;
		float ageInTicks = state.ageInTicks;
		float netHeadYaw = state.yRot;
		float headPitch = state.xRot;

	}

}