/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.creepycozy.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.creepycozy.CreepyCozyMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class CreepyCozyModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, CreepyCozyMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(CreepyCozyModItems.GHOST_SPAWN_EGG.get());
			tabData.accept(CreepyCozyModItems.OWL_SPAWN_EGG.get());
			tabData.accept(CreepyCozyModItems.GNOME_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(CreepyCozyModBlocks.HAUNTED_TULIP.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(CreepyCozyModItems.GHOST_WORLD.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(CreepyCozyModItems.GNOME_ARMOR_HELMET.get());
			tabData.accept(CreepyCozyModItems.GNOME_ARMOR_BOOTS.get());
		}
	}
}