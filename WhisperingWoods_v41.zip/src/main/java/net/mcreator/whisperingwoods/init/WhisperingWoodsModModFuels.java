/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.whisperingwoods.init;

import net.neoforged.neoforge.event.furnace.FurnaceFuelBurnTimeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;

@EventBusSubscriber
public class WhisperingWoodsModModFuels {
	@SubscribeEvent
	public static void furnaceFuelBurnTimeEvent(FurnaceFuelBurnTimeEvent event) {
		ItemStack itemstack = event.getItemStack();
		if (itemstack.getItem() == WhisperingWoodsModModBlocks.VIOLET_PLANKS.get().asItem())
			event.setBurnTime(300);
		else if (itemstack.getItem() == WhisperingWoodsModModBlocks.VIOLET_FENCE.get().asItem())
			event.setBurnTime(300);
		else if (itemstack.getItem() == WhisperingWoodsModModBlocks.VIOLET_FENCE_GATE.get().asItem())
			event.setBurnTime(300);
		else if (itemstack.getItem() == WhisperingWoodsModModBlocks.VIOLET_SLAB.get().asItem())
			event.setBurnTime(150);
		else if (itemstack.getItem() == WhisperingWoodsModModBlocks.VIOLET_DOOR.get().asItem())
			event.setBurnTime(200);
		else if (itemstack.getItem() == WhisperingWoodsModModBlocks.VIOLET_STAIRS.get().asItem())
			event.setBurnTime(300);
		else if (itemstack.getItem() == WhisperingWoodsModModBlocks.VIOLET_TRAPDOOR.get().asItem())
			event.setBurnTime(300);
		else if (itemstack.getItem() == WhisperingWoodsModModBlocks.VIOLET_PRESSURE_PLATE.get().asItem())
			event.setBurnTime(300);
		else if (itemstack.getItem() == WhisperingWoodsModModBlocks.VIOLET_BUTTON.get().asItem())
			event.setBurnTime(100);
		else if (itemstack.getItem() == WhisperingWoodsModModBlocks.VIOLET_LOG.get().asItem())
			event.setBurnTime(300);
		else if (itemstack.getItem() == WhisperingWoodsModModBlocks.STRIPPED_VIOLET_LOG.get().asItem())
			event.setBurnTime(300);
		else if (itemstack.getItem() == WhisperingWoodsModModBlocks.VIOLET_WOOD.get().asItem())
			event.setBurnTime(300);
		else if (itemstack.getItem() == WhisperingWoodsModModBlocks.STRIPPED_VIOLET_WOOD.get().asItem())
			event.setBurnTime(300);
		else if (itemstack.getItem() == WhisperingWoodsModModBlocks.VIOLET_TREE_SAPLING.get().asItem())
			event.setBurnTime(100);
	}
}