/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.whisperingwoods.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.core.registries.Registries;

import net.mcreator.whisperingwoods.world.features.VioletTreeFeatureFeature;
import net.mcreator.whisperingwoods.WhisperingWoodsModMod;

public class WhisperingWoodsModModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(Registries.FEATURE, WhisperingWoodsModMod.MODID);
	public static final DeferredHolder<Feature<?>, Feature<?>> VIOLET_TREE_FEATURE = REGISTRY.register("violet_tree_feature", VioletTreeFeatureFeature::new);
}