package net.mcreator.whisperingwoods.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.whisperingwoods.entity.OwlEntity;

public class OwlVariationProcedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		return (entity instanceof OwlEntity _datEntI ? _datEntI.getEntityData().get(OwlEntity.DATA_textureID) : 0) == 1;
	}
}