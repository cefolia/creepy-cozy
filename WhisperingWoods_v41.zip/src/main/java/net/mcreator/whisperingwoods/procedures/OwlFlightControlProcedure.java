package net.mcreator.whisperingwoods.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;

public class OwlFlightControlProcedure {
	public static void execute(LevelAccessor world, double x, double z, Entity entity) {
		if (entity == null)
			return;
		if (5 < entity.getY() - world.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (int) x, (int) z)) {
			entity.setDeltaMovement(new Vec3(0, (-0.2), 0));
		} else {
			entity.setDeltaMovement(new Vec3(0, 0.2, 0));
		}
	}
}