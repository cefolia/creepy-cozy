package net.mcreator.whisperingwoods.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;

public class VioletTreeFeature0AdditionalGenerationConditionProcedure {
	public static boolean execute(LevelAccessor world, double x, double y, double z) {
		boolean success = false;
		double xOffset = 0;
		double yOffset = 0;
		double zOffset = 0;
		success = true;
		if (!world.isEmptyBlock(BlockPos.containing(x, y + 1, z)) || !world.isEmptyBlock(BlockPos.containing(x, y + 2, z))) {
			success = false;
		}
		if (success) {
			yOffset = 1;
			while (yOffset < 7) {
				xOffset = -2;
				while (xOffset < 3) {
					zOffset = -2;
					while (zOffset < 3) {
						if (!(world.getBlockState(BlockPos.containing(x + xOffset, y + yOffset, z + zOffset))).is(BlockTags.create(ResourceLocation.parse("whispering_woods:violet_tree_replaceable")))) {
							success = false;
							break;
						} else {
							zOffset = zOffset + 1;
						}
					}
					if (!success) {
						break;
					} else {
						xOffset = xOffset + 1;
					}
				}
				if (!success) {
					break;
				} else {
					yOffset = yOffset + 1;
				}
			}
		}
		return success;
	}
}