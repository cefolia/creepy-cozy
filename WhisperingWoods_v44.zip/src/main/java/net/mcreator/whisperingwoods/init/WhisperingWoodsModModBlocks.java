/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.whisperingwoods.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.whisperingwoods.block.VioletWoodBlock;
import net.mcreator.whisperingwoods.block.VioletTreeSaplingBlock;
import net.mcreator.whisperingwoods.block.VioletTrapdoorBlock;
import net.mcreator.whisperingwoods.block.VioletStairsBlock;
import net.mcreator.whisperingwoods.block.VioletSlabBlock;
import net.mcreator.whisperingwoods.block.VioletPressurePlateBlock;
import net.mcreator.whisperingwoods.block.VioletPlanksBlock;
import net.mcreator.whisperingwoods.block.VioletLogBlock;
import net.mcreator.whisperingwoods.block.VioletLeavesBlock;
import net.mcreator.whisperingwoods.block.VioletFireflyBushBlock;
import net.mcreator.whisperingwoods.block.VioletFenceGateBlock;
import net.mcreator.whisperingwoods.block.VioletFenceBlock;
import net.mcreator.whisperingwoods.block.VioletDoorBlock;
import net.mcreator.whisperingwoods.block.VioletButtonBlock;
import net.mcreator.whisperingwoods.block.StrippedVioletWoodBlock;
import net.mcreator.whisperingwoods.block.StrippedVioletLogBlock;
import net.mcreator.whisperingwoods.block.ShelfMushroomBlock;
import net.mcreator.whisperingwoods.block.HauntedWildflowerBlock;
import net.mcreator.whisperingwoods.block.HauntedTulipBlock;
import net.mcreator.whisperingwoods.block.HauntedDandelionBlock;
import net.mcreator.whisperingwoods.block.HauntedCornflowerBlock;
import net.mcreator.whisperingwoods.block.GnomeHatBlock;
import net.mcreator.whisperingwoods.block.GhostWorldPortalBlock;
import net.mcreator.whisperingwoods.WhisperingWoodsModMod;

import java.util.function.Function;

public class WhisperingWoodsModModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(WhisperingWoodsModMod.MODID);
	public static final DeferredBlock<Block> HAUNTED_TULIP = register("haunted_tulip", HauntedTulipBlock::new);
	public static final DeferredBlock<Block> GHOST_WORLD_PORTAL = register("ghost_world_portal", GhostWorldPortalBlock::new);
	public static final DeferredBlock<Block> WHISPERING_LOG = register("whispering_log", VioletLogBlock::new);
	public static final DeferredBlock<Block> WHISPERING_WOOD = register("whispering_wood", VioletWoodBlock::new);
	public static final DeferredBlock<Block> STRIPPED_WHISPERING_LOG = register("stripped_whispering_log", StrippedVioletLogBlock::new);
	public static final DeferredBlock<Block> STRIPPED_WHISPERING_WOOD = register("stripped_whispering_wood", StrippedVioletWoodBlock::new);
	public static final DeferredBlock<Block> WHISPERING_PLANKS = register("whispering_planks", VioletPlanksBlock::new);
	public static final DeferredBlock<Block> WHISPERING_STAIRS = register("whispering_stairs", VioletStairsBlock::new);
	public static final DeferredBlock<Block> WHISPERING_LEAVES = register("whispering_leaves", VioletLeavesBlock::new);
	public static final DeferredBlock<Block> WHISPERING_SLAB = register("whispering_slab", VioletSlabBlock::new);
	public static final DeferredBlock<Block> HAUNTED_CORNFLOWER = register("haunted_cornflower", HauntedCornflowerBlock::new);
	public static final DeferredBlock<Block> WHISPERING_FENCE = register("whispering_fence", VioletFenceBlock::new);
	public static final DeferredBlock<Block> WHISPERING_FENCE_GATE = register("whispering_fence_gate", VioletFenceGateBlock::new);
	public static final DeferredBlock<Block> WHISPERING_DOOR = register("whispering_door", VioletDoorBlock::new);
	public static final DeferredBlock<Block> WHISPERING_TRAPDOOR = register("whispering_trapdoor", VioletTrapdoorBlock::new);
	public static final DeferredBlock<Block> WHISPERING_PRESSURE_PLATE = register("whispering_pressure_plate", VioletPressurePlateBlock::new);
	public static final DeferredBlock<Block> WHISPERING_BUTTON = register("whispering_button", VioletButtonBlock::new);
	public static final DeferredBlock<Block> HAUNTED_FIREFLY_BUSH = register("haunted_firefly_bush", VioletFireflyBushBlock::new);
	public static final DeferredBlock<Block> SHELF_MUSHROOM = register("shelf_mushroom", ShelfMushroomBlock::new);
	public static final DeferredBlock<Block> WHISPERING_TREE_SAPLING = register("whispering_tree_sapling", VioletTreeSaplingBlock::new);
	public static final DeferredBlock<Block> GNOME_HAT = register("gnome_hat", GnomeHatBlock::new);
	public static final DeferredBlock<Block> HAUNTED_DANDELION = register("haunted_dandelion", HauntedDandelionBlock::new);
	public static final DeferredBlock<Block> HAUNTED_WILDFLOWER = register("haunted_wildflower", HauntedWildflowerBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}