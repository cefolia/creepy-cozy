package net.mcreator.whisperingwoods.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;

public class VenisonItem extends Item {
	public VenisonItem(Item.Properties properties) {
		super(properties.food((new FoodProperties.Builder()).nutrition(3).saturationModifier(1.8f).build()));
	}
}