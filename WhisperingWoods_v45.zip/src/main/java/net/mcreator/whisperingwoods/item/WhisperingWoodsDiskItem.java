package net.mcreator.whisperingwoods.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

import net.mcreator.whisperingwoods.WhisperingWoodsModMod;

public class WhisperingWoodsDiskItem extends Item {
	public WhisperingWoodsDiskItem(Item.Properties properties) {
		super(properties.rarity(Rarity.UNCOMMON).jukeboxPlayable(ResourceKey.create(Registries.JUKEBOX_SONG, ResourceLocation.fromNamespaceAndPath(WhisperingWoodsModMod.MODID, "whispering_woods_disk"))));
	}
}