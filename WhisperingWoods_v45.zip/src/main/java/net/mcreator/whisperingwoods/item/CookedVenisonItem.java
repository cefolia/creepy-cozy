package net.mcreator.whisperingwoods.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;

public class CookedVenisonItem extends Item {
	public CookedVenisonItem(Item.Properties properties) {
		super(properties.food((new FoodProperties.Builder()).nutrition(8).saturationModifier(12.8f).build()));
	}
}