/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.whisperingwoods.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.whisperingwoods.client.renderer.OwlRenderer;
import net.mcreator.whisperingwoods.client.renderer.GnomeRenderer;
import net.mcreator.whisperingwoods.client.renderer.GhostRenderer;
import net.mcreator.whisperingwoods.client.renderer.GhostFishRenderer;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class WhisperingWoodsModModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(WhisperingWoodsModModEntities.GHOST.get(), GhostRenderer::new);
		event.registerEntityRenderer(WhisperingWoodsModModEntities.OWL.get(), OwlRenderer::new);
		event.registerEntityRenderer(WhisperingWoodsModModEntities.GNOME.get(), GnomeRenderer::new);
		event.registerEntityRenderer(WhisperingWoodsModModEntities.GHOST_FISH.get(), GhostFishRenderer::new);
	}
}